# VoiceCalculator

Something different. :)
